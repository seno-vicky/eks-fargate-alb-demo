## AWS Fargate Web App Tutorial

This is the source code for the AWS Fargate tutorial on https://www.learnaws.org/.
